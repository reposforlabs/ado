az group create --location northeurope --name webapps-rg
