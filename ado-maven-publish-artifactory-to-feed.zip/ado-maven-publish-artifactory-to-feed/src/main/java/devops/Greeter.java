package devops;

public class Greeter {
	public String sayHello() {
		return "Hello DevOps Engineers";
	}
}
